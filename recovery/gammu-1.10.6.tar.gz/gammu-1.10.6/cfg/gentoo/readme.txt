Hi folks,

1. To install this, create a directory
/usr/local/portage/net-dialup/gammu/files

2. Copy the gammu-0.85.ebuild to /usr/local/portage/net-dialup/gammu.

3. ebuild /usr/local/portage/net-dialup/gammu/gammu-0.85.ebuild digest

4. emerge gammu

Just install it the way you want.

Ciao
ST Lim
