
#include "common.h"

#include <afxwin.h>
#include <afxext.h>
#include <afxcview.h>

#include "resource.h"
#include ".\editpbk.h"

CEditPbkDlg::CEditPbkDlg() : CDialog(CEditPbkDlg::IDD)
{
}

void CEditPbkDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CEditPbkDlg, CDialog)
END_MESSAGE_MAP()
