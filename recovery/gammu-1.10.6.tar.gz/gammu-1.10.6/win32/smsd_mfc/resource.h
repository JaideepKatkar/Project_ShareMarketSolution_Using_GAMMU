//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by mgui.rc
//
#define IDD_LOGUSER                     8
#define IDM_ABOUT                       0x0010
#define IDR_MENU1                       101
#define IDD_SENDSMS                     101
#define IDR_MAIN                        101
#define IDS_ABOUT                       102
#define IDR_TXT                         103
#define IDD_ABOUT                       103
#define ID_MODEM1                       103
#define IDR_EMPTY                       104
#define ID_MODEM2                       105
#define ID_MODEM3                       106
#define IDD_CONFIG                      107
#define ID_MODEM4                       107
#define IDD_EDITPBK                     108
#define IDC_BUTTON1                     1004
#define IDC_EDIT1                       1005
#define IDC_EDIT2                       1006
#define IDC_EDIT3                       1007
#define IDC_BUTTON2                     1008
#define IDC_LIST2                       1010
#define IDC_BUTTON3                     1011
#define IDC_CHECK1                      1014
#define IDC_CHECK2                      1015
#define IDC_BUTTON4                     1016
#define IDC_CHECK3                      1018
#define IDC_COMBO1                      1019
#define IDC_TAB1                        1020
#define IDC_TREE1                       1021
#define IDC_MULTIPAGE1                  1022
#define IDC_CHECK4                      1023
#define IDC_CHECK5                      1024
#define IDC_COMBO2                      1025
#define IDC_COMBO3                      1026
#define IDC_LIST1                       1027
#define IDC_STATIC3                     1028
#define IDC_STATIC4                     1029
#define IDC_STATIC5                     1030
#define IDC_STATIC6                     1031
#define IDC_STATIC2                     1032
#define IDC_BUTTON5                     1033
#define IDC_BUTTON6                     1034
#define ID_FILE_LOGASNEWUSER            40001
#define ID_Menu                         40002
#define ID_FILE_EXIT                    40003
#define ID_HELP_ABOUT                   40005
#define ID_TOOLS_CONFIG                 40008
#define ID_TOOLS_SENDSMS                40009
#define ID_TOOLS_DEVICEINFO             40010
#define ID_VIEW_STATUSBAR               40018
#define ID_WINDOW_CLOSEALL              40019
#define ID_EDIT_DELETE                  40020
#define ID_TOOLS_PHONEBOOK              40026
#define IDS_EMTY                        0xE000
#define IDS_EMPTY                       0xE000

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40028
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
