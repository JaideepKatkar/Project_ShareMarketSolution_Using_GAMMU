/* (c) 2002-2003 by Marcin Wiacek */

void decodesniff	(int argc, char *argv[]);
void decodebinarydump	(int argc, char *argv[]);

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
