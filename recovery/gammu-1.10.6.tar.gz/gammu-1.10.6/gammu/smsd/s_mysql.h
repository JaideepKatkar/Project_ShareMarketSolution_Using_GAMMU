/* (c) 2004 by Marcin Wiacek */

#ifdef HAVE_MYSQL_MYSQL_H

extern GSM_SMSDService SMSDMySQL;

#endif

/* How should editor hadle tabs in this file? Add editor commands here.
 * vim: noexpandtab sw=8 ts=8 sts=8:
 */
